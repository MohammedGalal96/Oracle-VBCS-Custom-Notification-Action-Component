define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FireCustomNotificationActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.summary 
     * @param {string} params.message 
     * @param {string} params.display_mode 
     * @param {string} params.duration 
     * @param {string} params.notification_type 
     * @param {string} params.position 
     * @param {string} params.theme 
     * @param {string} params.backgroundColor 
     * @param {string} params.iconColor 
     * @param {string} params.lineColor 
     * @param {string} params.icon 
     */
    async run(context, { summary, message, display_mode, duration, notification_type, position, theme, backgroundColor, iconColor, lineColor, icon }) {
      const { $page, $flow, $application, $constants, $variables } = context;





      await Actions.runAction(context, {
        module: 'custom_notification/notification',
        parameters: {
          summary: summary,
          message: message,
          displayMode: display_mode,
          duration: duration,
          notificationType: notification_type,
          position: position,
          theme: theme,
          backgroundColor: backgroundColor,
          iconColor: iconColor,
          lineColor: lineColor,
          icon: icon
        },
      });
    }
  }

  return FireCustomNotificationActionChain;
});
